<section id="find-treatments">
    <div class="container">
        <div class="row">
            <div class="col-xs-3">
                <h4><a href="/departments/tailored_treatment.php">나에게 맞는 <i>치료 찾기</i> <small>PERSONALIZED TREATMENT</small></a></h4>
            </div>
            <div class="col-xs-9">
                <ul>
                    <li><a href="/departments/tailored_treatment.php?cnum=0">머리/목<br>통증</a></li>
                    <li><a href="/departments/tailored_treatment.php?cnum=1">어깨 통증</a></li>
                    <li><a href="/departments/tailored_treatment.php?cnum=2">팔 통증</a></li>
                    <li><a href="/departments/tailored_treatment.php?cnum=3">배/허리/<br>골반 통증</a></li>
                    <li><a href="/departments/tailored_treatment.php?cnum=4">다리 통증</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>