<div id="footer">
	<div class="con">
		<p class="logo"></p>
		<p class="add">
			개인정보등등 모든관리책임자 : 정규정 ☎ : 010-6332-9327 / 서울시 중구 중림동 새마을금고 B/D 3층<br>
			Copyright ⓒ 2012 Movement k. All rights reserved.
		</p>
	</div>
</div>