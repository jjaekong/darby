<?
include_once $_SERVER['DOCUMENT_ROOT']."/board/config/use_db.php";
include $dir.$configDir."/admin_check.php";

foreach($_REQUEST as $KEY => $VALUES){
	if($KEY == "Content"){
		${$KEY} = get_text($VALUES);
		//echo $KEY." : ".${$KEY};
	} else {
		${$KEY} = preg_replace("/\"/", "&#034;", get_text($VALUES));
	}
}

$TableConfigDB = $site_prefix."board_setting";
$TableBoardName = $site_prefix."board_".$BoardName;

$blist = get_board_setting($bidx);
$brow = $blist[0];
$mode = $site_prefix."board_".$brow["BoardName"];

if($brow["BoardName"] == "product"){
	$bd3 = implode(",",$maker);
}

$sql_common = "bd1 = '".$bd1."', bd2 = '".$bd2."', bd3 = '".$bd3."', bd4 = '".$bd4."', bd5 = '".$bd5."', bd6 = '".$bd6."', bd7 = '".$bd7."', bd8 = '".$bd8."', bd9 = '".$bd9."', bd10 = '".$bd10."', border = '".$border."', ";

$upload_max_filesize = ini_get('upload_max_filesize');
if(empty($BoardName)) $BoardName = $brow["BoardName"];
$file_num = $brow["FileCnt"];
$uploaddir = $dir."/upload/".$BoardName."/";

$dir_ck = is_dir($uploaddir);

if($dir_ck != "1"){
	if(!@mkdir("$uploaddir", 0707)){ echo "디렉토리 생성실패"; exit;}
	if(!@chmod("$uploaddir", 0707)){ echo "퍼미션변경 실패"; exit;}
}

$chars_array = array_merge(range(0,9), range('a','z'), range('A','Z'));
// 가변 파일 업로드
$file_upload_msg = "";
$upload = array();
for ($i=0; $i<count($_FILES[bf_file][name]); $i++) 
{
    // 삭제에 체크가 되어있다면 파일을 삭제합니다.
    if ($_POST[bf_file_del][$i]) 
    {
        $upload[$i][del_check] = true;

        $row = sql_fetch(" select file_source from $fileTable where board_table = '$mode' and board_idx = '$BoardIdx' and file_no = '$i' ");
        @unlink("$uploaddir/$row[file_source]");
    }
    else
        $upload[$i][del_check] = false;

    $tmp_file  = $_FILES[bf_file][tmp_name][$i];
    $filename  = $_FILES[bf_file][name][$i];
    $filesize  = $_FILES[bf_file][size][$i];

    // 서버에 설정된 값보다 큰파일을 업로드 한다면
    if ($filename)
    {
        if ($_FILES[bf_file][error][$i] == 1)
        {
            $file_upload_msg .= "\'{$filename}\' 파일의 용량이 서버에 설정($upload_max_filesize)된 값보다 크므로 업로드 할 수 없습니다.\\n";
            continue;
        }
        else if ($_FILES[bf_file][error][$i] != 0)
        {
            $file_upload_msg .= "\'{$filename}\' 파일이 정상적으로 업로드 되지 않았습니다.\\n";
            continue;
        }
    }

    if (is_uploaded_file($tmp_file)) 
    {
        /* 관리자가 아니면서 설정한 업로드 사이즈보다 크다면 건너뜀
        if (!$is_admin && $filesize > $board[bo_upload_size]) 
        {
            $file_upload_msg .= "\'{$filename}\' 파일의 용량(".number_format($filesize)." 바이트)이 게시판에 설정(".number_format($board[bo_upload_size])." 바이트)된 값보다 크므로 업로드 하지 않습니다.\\n";
            continue;
        }
		*/

        //=================================================================\
        // 090714
        // 이미지나 플래시 파일에 악성코드를 심어 업로드 하는 경우를 방지
        // 에러메세지는 출력하지 않는다.
        //-----------------------------------------------------------------
        $timg = @getimagesize($tmp_file);
        // image type
        if ( preg_match("/\.(jpg|bmp|gif|png)$/i", $filename) ||
             preg_match("/\.(swf)$/i", $filename) ) 
        {
            if ($timg[2] < 1 || $timg[2] > 16)
            {
                //$file_upload_msg .= "\'{$filename}\' 파일이 이미지나 플래시 파일이 아닙니다.\\n";
                continue;
            }
        }
        //=================================================================

        $upload[$i][image] = $timg;

        // 4.00.11 - 글답변에서 파일 업로드시 원글의 파일이 삭제되는 오류를 수정
        if ($w == 'u')
        {
            // 존재하는 파일이 있다면 삭제합니다.
            $row = sql_fetch(" select file_source from $fileTable where board_table = '$mode' and board_idx = '$BoardIdx' and bf_no = '$i' ");
            @unlink("$uploaddir/$row[bf_file]");
        }

        // 프로그램 원래 파일명
        $upload[$i][file_name] = $filename;
        $upload[$i][file_filesize] = $filesize;

        // 아래의 문자열이 들어간 파일은 -x 를 붙여서 웹경로를 알더라도 실행을 하지 못하도록 함
        $filename = preg_replace("/\.(php|phtm|htm|cgi|pl|exe|jsp|asp|inc)/i", "$0-x", $filename);

        // 접미사를 붙인 파일명
        //$upload[$i][file] = abs(ip2long($_SERVER[REMOTE_ADDR])).'_'.substr(md5(uniqid($g4[server_time])),0,8).'_'.urlencode($filename);
        // 달빛온도님 수정 : 한글파일은 urlencode($filename) 처리를 할경우 '%'를 붙여주게 되는데 '%'표시는 미디어플레이어가 인식을 못하기 때문에 재생이 안됩니다. 그래서 변경한 파일명에서 '%'부분을 빼주면 해결됩니다. 
        //$upload[$i][file] = abs(ip2long($_SERVER[REMOTE_ADDR])).'_'.substr(md5(uniqid($g4[server_time])),0,8).'_'.str_replace('%', '', urlencode($filename)); 
        shuffle($chars_array);
        $shuffle = implode("", $chars_array);

        // 첨부파일 첨부시 첨부파일명에 공백이 포함되어 있으면 일부 PC에서 보이지 않거나 다운로드 되지 않는 현상이 있습니다. (길상여의 님 090925)
        //$upload[$i][file] = abs(ip2long($_SERVER[REMOTE_ADDR])).'_'.substr($shuffle,0,8).'_'.str_replace('%', '', urlencode($filename)); 
        $upload[$i][file_source] = abs(ip2long($_SERVER[REMOTE_ADDR])).'_'.substr($shuffle,0,8).'_'.str_replace('%', '', urlencode(str_replace(' ', '_', $filename))); 

        $dest_file = "$uploaddir/" . $upload[$i][file_source];

        // 업로드가 안된다면 에러메세지 출력하고 죽어버립니다.
        $error_code = move_uploaded_file($tmp_file, $dest_file) or die($_FILES[bf_file][error][$i]);

        // 올라간 파일의 퍼미션을 변경합니다.
        chmod($dest_file, 0606);

        //$upload[$i][image] = @getimagesize($dest_file);

    }
}

switch($workType){
	case "BC":
		$sql = " select count(BoardName) as cnt from ".$TableConfigDB." where BoardName = '".$BoardName."' ";
		$row = sql_fetch($sql);
		if($row["cnt"] > 0){
			GetAlert("이미 존재하는 게시판 이름입니다.","BACK");
			exit;
		}
		$sql = " insert into ".$TableConfigDB." set
								BoardName = '".$BoardName."',
								BoardTitle = '".$BoardTitle."',
								BoardType = '".$BoardType."',
								Category = '".$Category."',
								RepleFlag = '".$RepleFlag."',
								RepleAuthority = '".$RepleAuthority."',
								CommentFlag = '".$CommentFlag."',
								CommentAuthority = '".$CommentAuthority."',
								WriteAuthority = '".$WriteAuthority."',
								ViewAuthority = '".$ViewAuthority."',
								LinkFlag = '".$LinkFlag."',
								HtmlFlag = '".$HtmlFlag."',
								Secret = '".$Secret."',
								Flag = '".$Flag."',
								RegDate = now(),
								FileCnt = '".$FileCnt."',
								ViewInList = '".$ViewInList."' ";
		$result = sql_query($sql);

		$csql = " create table ".$TableBoardName." (
								BoardIdx int(11) NOT NULL AUTO_INCREMENT,
								UserIdx int,
								UserID varchar(255),
								UserName varchar(255),
								UserEmail varchar(255),
								UserPw varchar(100),
								UserIP varchar(20),
								Notice tinyint,
								Title varchar(255),
								Category varchar(255),
								Content text,
								Ref int,
								ReStep int,
								ReLevel int,
								Link1 varchar(255),
								Link2 varchar(255),
								bd1 varchar(255),
								bd2 varchar(255),
								bd3 varchar(255),
								bd4 varchar(255),
								bd5 varchar(255),
								bd6 varchar(255),
								bd7 varchar(255),
								bd8 varchar(255),
								bd9 varchar(255),
								bd10 varchar(255),
								border int(11),
								Secret varchar(4),
								SecretFlag tinyint,
								HtmlChk varchar(1) NOT NULL default 'Y',
								ReadNum int NOT NULL default '0',
								RegDate datetime,
								FileCnt int(11),
								ViewInList int(11),
								PRIMARY KEY( `BoardIdx` ) ) ENGINE = MYISAM DEFAULT CHARSET = utf8 AUTO_INCREMENT = 1; ";
		$cresult = sql_query($csql);

		$updir = $dir."/upload/".$BoardName;
		if(!is_dir($updir)){
			@mkdir($updir,0707);
			@chmod($updir,0707);
		}

		GetAlert("게시판 생성완료",$URI);

		break;
	case "BM":
		$sql = " update ".$TableConfigDB." set
								BoardType = '".$BoardType."',
								BoardTitle = '".$BoardTitle."',
								Category = '".$Category."',
								RepleFlag = '".$RepleFlag."',
								RepleAuthority = '".$RepleAuthority."',
								CommentFlag = '".$CommentFlag."',
								CommentAuthority = '".$CommentAuthority."',
								WriteAuthority = '".$WriteAuthority."',
								ViewAuthority = '".$ViewAuthority."',
								LinkFlag = '".$LinkFlag."',
								HtmlFlag = '".$HtmlFlag."',
								Secret = '".$Secret."',
								Flag = '".$Flag."',
								FileCnt = '".$FileCnt."',
								ViewInList = '".$ViewInList."'
						where
								Idx = '".$Idx."' ";
		$result = sql_query($sql);

		GetAlert("게시판 수정완료",$URI);
		break;
	case "BD":
		$sql = " select * from ".$TableConfigDB." where Idx = '".$Idx."' ";
		$row = sql_fetch($sql);

		$mode = $site_prefix."board_".$row["BoardName"];
		
		$dtsql = " drop table ".$mode;
		$dtresult = sql_query($dtsql);

		$cdsql = " delete from ".$site_prefix."board_comment where DBName = '".$mode."' ";
		$cdresult = sql_query($cdsql);

		$fdsql = " delete from ".$site_prefix."file where board_table = '".$mode."' ";
		$fdresult = sql_query($fdsql);

		$df = $dir."/upload/".$row["BoardName"];
		$folder = opendir($df);
		$i=0;
		while($file = readdir($folder)){
			if($i >= 2) unlink($df."/".$file);
			$i++;
		}
		rmdir($df);

		$dsql = " delete from ".$TableConfigDB." where Idx = '".$Idx."' ";
		$dresult = sql_query($dsql);

		GetAlert("게시판 삭제완료",$URI);
		break;
	case "D":
		$f_row = get_file($mode,$idx);

		for($i=0;$i<$f_row[count];$i++){
			if(!empty($f_row[$i][file_source]) && file_exists($dir."/upload/".$brow["BoardName"]."/".$f_row[$i]["file_source"])){
				@unlink($dir."/upload/".$brow["BoardName"]."/".$f_row[$i]["file_source"]);
				$fSQL = "delete from ".$fileTable." where board_table='".$mode."' and board_idx=".$idx." and file_no=".$i;
				$fResult = sql_query($fSQL);
			}
		}

		$dsql = "delete from ".$mode." where BoardIdx=".$idx;
		$dresult = sql_query($dsql);

		GetAlert("게시물을 삭제 하였습니다",$URI);
		break;
	case "I":
		$asql = "select * from ".$site_prefix."admin where admin_id = '".$user[ID]."' ";
		$arow = sql_fetch($asql);

		if(!$UserID && empty($idx)){
			$UserID = $arow["admin_id"];
			$UserName = $arow["admin_name"];
			$UserEmail = $arow["admin_email"];
			$UserIP = $_SERVER["REMOTE_ADDR"];
		}

		if(empty($UserEmail)) $UserEmail = $Email1."@".$Email2;

		if(!$HtmlChk) $HtmlChk = 'Y';

		$UserPw = sql_password($arow[admin_pwd]);

		$SQL = "select max(BoardIdx) as midx from ".$mode;
		$Result = sql_query($SQL);
		
		if(!$Result){
		  $BoardIdx = 1;
		}
		else {
			$row = sql_fetch($SQL);
			$idx = $row[midx]+1;
		}
		if(isset($_REQUEST["Ref"]) && $_REQUEST["Ref"] != ""){
		   $Ref      = $_REQUEST["Ref"];
		   $ReStep  = $_REQUEST["ReStep"] + 1;
		   $ReLevel = $_REQUEST["ReLevel"] + 1;

		   $SQL = "update ".$mode." set ReStep = ReStep+1 where Ref=";
		   $SQL .= $Ref." AND ReStep > ".$_REQUEST["ReStep"];

		   sql_query($SQL);

		   $UserPw = $ppw;

		}
		else{
		   
		   $Ref      = $idx;
		   $ReStep  = 0;
		   $ReLevel = 0;
		}

		$sql_date = "RegDate = now() ";

		$SQL  = "insert into ".$mode." 
							set Notice = '$Notice',
								Category = '$Category',
								Title = '$Title',
								Content = '$Content',
								UserIdx = '$UserIdx',
								UserID = '$UserID',
								UserName = '$UserName',
								UserEmail = '$UserEmail',
								UserPw = '$UserPw',
								UserIP = '$UserIP',
								Secret = '$Secret',
								SecretFlag = '$SecretFlag',
								HtmlChk='$HtmlChk',
								Link1 = '$Link1',
								Link2 = '$Link2',
								$sql_common
								Ref = '$Ref',
								ReStep = '$ReStep',
								ReLevel = '$ReLevel',
								$sql_date ";

		$Result = sql_query($SQL);
		if(!$Result){
		  err_back("게시물 등록에 실패했습니다. 오류 1-2");
		}

		$idx = get_max($mode,"BoardIdx");
		$works = "입력";
		break;
	case "SM":
		$sql = " update ".$site_prefix."board_account set bd8 = '".$bd8."', bd9 = '".$bd9."' where BoardIdx = '".$idx."' ";
		$result = sql_query($sql);
		GetAlert("상태를 저장 하였습니다.","/board/admn/board/board_view.php?Category=&sfl=".$sfl."&stx=".$stx."&page=".$page."&bidx=6&cat=".$cat."&sdate=".$sdate."&edate=".$edate."&aname=".$aname."&acat=".$acat."&acharge=".$acharge."&idx=".$idx);
		break;
	case "AD":
		$sql = " update ".$site_prefix."board_account set bd10 = 'Y' where BoardIdx = '".$idx."' ";
		$result = sql_query($sql);
		$works = "취소";
		GetAlert("예약을 ".$works." 하였습니다.","/board/admn/board/board.php?bidx=6");
		break;
	case "AE":
		$sql = " update ".$site_prefix."board_account set bd10 = 'E' where BoardIdx = '".$idx."' ";
		$result = sql_query($sql);
		$works = "완료";
		GetAlert("예약을 ".$works." 하였습니다.","/board/admn/board/board.php?bidx=6");
		break;
	case "M":
		$asql = "select * from ".$site_prefix."admin where admin_id = '".$user[ID]."' ";
		$arow = sql_fetch($asql);

		if(!$UserID && empty($idx)){
			$UserID = $arow["admin_id"];
			$UserName = $arow["admin_name"];
			$UserEmail = $arow["admin_email"];
			$UserIP = $_SERVER["REMOTE_ADDR"];
		}

		if(empty($UserEmail)) $UserEmail = $Email1."@".$Email2;

		if(!$HtmlChk) $HtmlChk = 'Y';

		$UserPw = sql_password($arow[admin_pwd]);

		$SQL = "update ".$mode." set 
						Title='".$Title."', 
						Notice='".$Notice."',
						Content='".$Content."',
						$sql_common
						Secret = '$Secret',
						SecretFlag = '$SecretFlag',
						HtmlChk='".$HtmlChk."',
						UserName = '".$UserName."',
						UserEmail='".$UserEmail."',
						Category='".$Category."',
						Link1='".$Link1."',
						Link2='".$Link2."'
					where
						BoardIdx='".$idx."'";
		$Result = sql_query($SQL);
		$works = "수정";
		break;
}

switch($workType){
	case "I":
	case "M":
		for ($i=0; $i<count($upload); $i++) 
		{
			$row = sql_fetch(" select count(*) as cnt from $fileTable where board_table = '$mode' and board_idx = '$idx' and file_no = '$i' ");
			if ($row[cnt]) 
			{
				// 삭제에 체크가 있거나 파일이 있다면 업데이트를 합니다.
				// 그렇지 않다면 내용만 업데이트 합니다.
				if ($upload[$i][del_check] || $upload[$i][file_source]) 
				{
					$sql = " update $fileTable
								set file_source = '{$upload[$i][file_source]}',
									file_name = '{$upload[$i][file_name]}',
									file_filesize = '{$upload[$i][file_filesize]}',
									file_width = '{$upload[$i][image][0]}',
									file_height = '{$upload[$i][image][1]}',
									file_category = '{$upload[$i][image][2]}',
									RegDate = now()
							  where board_table = '$mode'
								and board_idx = '$idx'
								and file_no = '$i' ";
					sql_query($sql);
				}
			} 
			else 
			{
				$sql = " insert into $fileTable
							set board_table = '$mode',
								board_idx = '$idx',
								file_no = '$i',
								file_source = '{$upload[$i][file_source]}',
								file_name = '{$upload[$i][file_name]}',
								file_filesize = '{$upload[$i][file_filesize]}',
								file_width = '{$upload[$i][image][0]}',
								file_height = '{$upload[$i][image][1]}',
								file_category = '{$upload[$i][image][2]}',
								RegDate = now() ";
				sql_query($sql);
			}
		//echo $sql."<br>";
		}
		// 업로드된 파일 내용에서 가장 큰 번호를 얻어 거꾸로 확인해 가면서
		// 파일 정보가 없다면 테이블의 내용을 삭제합니다.
		$sql = " select max(file_no) as max_bf_no from $fileTable where board_table = '$mode' and board_idx = '$idx' ";
		$row = sql_fetch($sql);

		for ($i=(int)$row[max_bf_no]; $i>=0; $i--) 
		{
			$sql2 = " select file_source from $fileTable where board_table = '$mode' and board_idx = '$idx' and file_no = '$i' ";
			$row2 = sql_fetch($sql2);
			// 정보가 있다면 빠집니다.
			if ($row2[file_source]) break;

			// 그렇지 않다면 정보를 삭제합니다.
			$sql3 = " delete from $fileTable where board_table = '$mode' and board_idx = '$idx' and file_no = '$i' ";
			sql_query($sql3);

		//	echo $sql3;
		}

		GetAlert("게시물을 ".$works." 하였습니다.",$URI.$idx);
		break;
}
?>
