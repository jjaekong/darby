<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<script>
location.href="../index.php";
</script>
</head>

<body>
</body>
</html>