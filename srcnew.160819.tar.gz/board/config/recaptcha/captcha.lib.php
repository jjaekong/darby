<?php
require(dirname(__FILE__).'/recaptcha.lib.php');
?>