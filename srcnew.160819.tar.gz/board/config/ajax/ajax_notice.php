<?
ob_start();
include $_SERVER["DOCUMENT_ROOT"]."/board/config/use_db.php";
?>
<link href="css/dgmore_style.css" rel="stylesheet" type="text/css" />
<div class="main_notice">
    <ul>
        <li class="notice_title"><img src="image/main_img/notice_title.png" /></li>
        <li class="notice_text">2012 광고연감 게재 양식입니다.</li>
        <li class="notice_text">2012 광고연감 게재 양식입니다.</li>
        <li class="notice_text">2012 광고연감 게재 양식입니다.</li>
        <li class="notice_text">2012 광고연감 게재 양식입니다.</li>
        <li class="notice_text">2012 광고연감 게재 양식입니다.</li>
    </ul>
</div>