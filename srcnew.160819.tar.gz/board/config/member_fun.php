<?
$usermail = array();
$usermail[1]="chol.com";
$usermail[2]="dreamwiz.com";
$usermail[3]="empal.com";
$usermail[4]="freechal.com";
$usermail[5]="hanafos.com";
$usermail[6]="paran.com";
$usermail[7]="hotmail.com";
$usermail[8]="hanmail.net";
$usermail[9]="korea.com";
$usermail[10]="lycos.co.kr";
$usermail[11]="naver.com";
$usermail[12]="netian.com";
$usermail[13]="nate.com";
$usermail[14]="yahoo.co.kr";
?>
<script src="../include/userDefineFunction.js"></script>
