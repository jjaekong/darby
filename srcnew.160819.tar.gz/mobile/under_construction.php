<?php require_once($_SERVER['DOCUMENT_ROOT'].'/mobile/inc/dochead.php'); ?>
</head>
<body>
    <?php require_once($_SERVER['DOCUMENT_ROOT'].'/mobile/inc/header.php'); ?>
    <main id="content">
        <section class="under-construction">
            <div class="container">
                <h1>컨텐츠 준비 중입니다.</h1>
                <p>
                    이용에 불편을 드려서 죄송합니다.<br>
                    빠른 시일내로 정상 운영하도록 하겠습니다.
                </p>
            </div>
        </section>
    </main>
    <?php require_once($_SERVER['DOCUMENT_ROOT'].'/mobile/inc/footer.php'); ?>
    <?php require_once($_SERVER['DOCUMENT_ROOT'].'/mobile/inc/docfoot.php'); ?>
</body>
</html>