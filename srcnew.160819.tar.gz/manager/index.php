<script>
location.href = '/board/admn/';
</script>