<?php require_once($_SERVER['DOCUMENT_ROOT'].'/inc/dochead_sub.php'); ?>
<link href="/css/introduce.css" rel="stylesheet">
</head>
<body style="background:#000;opacity:85;filter:alpha(opacity=85);">

	<!-- 실제 작업 영역 -->
	<div id="popMap">
		<p><a href="javascript:;"><img src="../images/introduce/btn_close.png" alt="닫기"/></a></p>
		<div class="map">지도 노출영역 1170*500</div>
		<span>Adress : 경기도 광주시 초월읍 지월리 729-6   /   Tel : 1577-3622</span>
	</div>
	<!-- // 실제 작업 영역 -->

</body>
</html>