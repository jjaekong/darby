<?php
include_once $_SERVER["DOCUMENT_ROOT"]."/board/config/use_db.php";
?>