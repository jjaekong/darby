<?php require_once($_SERVER['DOCUMENT_ROOT'].'/inc/dochead_sub.php'); ?>
<link href="/css/member.css" rel="stylesheet">
</head>
<body>
<script>
location.href = "/board/module/incmember/logout.php";
</script>
</body>
</html>